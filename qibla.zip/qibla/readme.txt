QiblaCalc  
Version 1.0 
 
 
Program & Documentation by Dr. Monzur Ahmed 
27 Poplar Road, Birmingham, B11 1UH, U.K. 
 
Copyright 1998. All Rights Reserved.  
 
Email:	monzur@bigfoot.com 
		monz@starlight.demon.co.uk 
 
Homepages:	http://www.starlight.demon.co.uk/qibla 
		http://www.ummah.org.uk/software/qibla 
 
Released:	7th May 1998 
 
 
 
 
 
 
CONTENTS 
---------------------------------------------------------------------
------- 
 
0. COPYRIGHT 
 
1. INTRODUCTION 
 
2. GETTING STARTED 
 
3. USING THE PROGRAM 
 
4. DISCLAIMER 
 
5. CONCLUSIONS 
 
 
---------------------------------------------------------------------
------- 
0. COPYRIGHT 
---------------------------------------------------------------------
------- 
 
QiblaCalc and this document are copyright (c) by Dr. Monzur Ahmed 
1998. All rights reserved. 
 
Data/graphics/maps produced by QiblaCalc may be used if accompanied 
by the following acknowledgement: 
 
"data/graphics/map* from QiblaCalc 1.0 by Dr. Monzur Ahmed." 
 
(*as appropriate) 
 
On a Web page an optional link may be made to one of the QiblaCalc  
homepages: 
 
http://www.starlight.demon.co.uk/qibla 
http://www.ummah.org.uk/software/qibla 
 
The colour earth map in QiblaCalc is copyright The Living Earth, Inc. 
and is used with permission. 
  
QiblaCalc may be copied and distributed freely as long as all files 
are copied and no charge is made (other than a nominal charge for 
media). 
 
No alterations should be made to the program or documentation and the 
program should be distributed as it's original unmodified ZIP file 
(qibla10.zip).  
 
 
---------------------------------------------------------------------
------- 
1. INTRODUCTION 
---------------------------------------------------------------------
------- 
 
 
QiblaCalc is a Windows program which calculates the Qibla direction 
(i.e direction of the Kabbah) from any location on earth. Unlike 
other programs which give the direction relative to true north, 
QiblaCalc also gives the direction relative to magnetic north as 
determined by a compass. This is achieved using a sophisticated 
geomagnetic field model to calculate the strength and direction of 
the earth's magnetic field at any location. The program also displays 
the Magnetic Declination (Mag Dec) which is the difference in degrees 
between magnetic and true north. For example, if the Mag Dec is +5 
degrees, then magnetic north is 5 degrees east of true north. If Mag 
Dec is -5 degrees, then magnetic north is 5 deg west of true north.   
 
QiblaCalc gives dynamic real-time data as you pass the mouse cursor 
over a beautiful map of the earth. QiblaCalc also produces spherical 
maps of the earth as it would appear from space from a point above 
your location. Apart from Qibla direction, QiblaCalc can also 
determine the distance between any two locations and the direction of 
*any* location from *any* other location.  
 
 
 
---------------------------------------------------------------------
------- 
2. GETTING STARTED 
---------------------------------------------------------------------
------- 
 
2.1 Minimum system requirements 
=============================== 
 
The minimum system requirements to run QiblaCalc are: 
 
* PC or compatible running Windows 3.1 or 95 or higher. 
 
* One floppy drive (hard drive recommended). 
 
* Colour VGA display with 256 colours or better. 
 
 
2.2 Files included 
================== 
 
The following files should be included on the distribution disk or 
be present after unzipping the qibla10.zip archive: 
 
QIBLA10.EXE		The main program 
README.TXT		This file 
 
 
---------------------------------------------------------------------
------- 
3. USING THE PROGRAM 
---------------------------------------------------------------------
------- 
 
When the program is run, there are basically 3 modes which are 
invoked using either the button bar or the 'Calculate' menu: 
 
3.1. Map 
======== 
 
Here you will see a map of the world. The map can be either 'natural' 
or 'political'. Moving the mouse cursor over the map results in a 
dynamic read-out of latitude, longitude, magnetic declination, qibla 
direction from true north, qibla direction from magnetic north and 
distance to Makkah. 
 
Note that magnetic declination varies from place to place and with 
date. QiblaCalc uses the date from the system clock to calculate the 
magnetic declination. The geomagnetic model used in QiblaCalc is most 
accurate between 1990 and 2000. The accuracy falls off slightly 
outside this range. Future versions of QiblaCalc will update the 
geomagnetic field model to cover a greater time span. 
 
 
3.2. Accurate Qibla Calculation 
=============================== 
 
In this mode, you can enter your latitude and longitude accurately 
(to a fraction of a second). Click the calculate button to obtain 
Qibla direction, Magnetic Declination, distance to Makkah and a 
spherical map of the earth as it would be seen from space from a 
point directly above your location. The map shows unambiguously why 
your Qibla direction is as indicated by the program and not what you 
would expect by drawing a straight line on a *flat* map projection. 
 
 
3.3. General 
============ 
 
In this mode, you can enter the latitudes and longitudes of any *two* 
locations (A and B) to obtain the bearing of B from A, the Magnetic 
Declination at A and the distance between A and B. 
 
 
 
---------------------------------------------------------------------
-------- 
4. DISCLAIMER 
---------------------------------------------------------------------
-------- 
 
THIS SOFTWARE AND ACCOMPANYING WRITTEN MATERIALS (INCLUDING 
INSTRUCTIONS  
FOR USE) ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND. FURTHER,  
THE AUTHOR, DOES NOT WARRANT, GUARANTEE, OR MAKE ANY REPRESENTATIONS  
REGARDING THE USE, OR THE RESULTS OF USE, OF THE SOFTWARE OR WRITTEN  
MATERIALS IN TERMS OF CORRECTNESS, ACCURACY, RELIABILITY, 
CURRENTNESS, OR  
OTHERWISE. THE ENTIRE RISK AS TO THE RESULTS AND PERFORMANCE OF THE  
SOFTWARE IS ASSUMED BY THE USER. 
  
NEITHER THE AUTHOR NOR ANYONE ELSE WHO HAS BEEN INVOLVED IN THE 
CREATION,  
TESTING OR DELIVERY OF THIS PRODUCT SHALL BE LIABLE FOR ANY DIRECT, 
INDIRECT, CONSEQUENTIAL OR INCIDENTAL DAMAGES (INCLUDING DAMAGES FOR  
LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION, LOSS OF BUSINESS  
INFORMATION, AND THE LIKE) ARISING OUT OF THE USE OR INABILITY TO USE  
SUCH PRODUCT. 
  
	 
---------------------------------------------------------------------
------- 
5. CONCLUSIONS 
---------------------------------------------------------------------
------- 
 
I hope that you enjoy using QiblaCalc and find it useful. QiblaCalc 
is in a state of constant development. All suggestions and comments 
which may improve the program are welcomed. 
 
 
---------------------------------------------------------------------
------- 
Dr. Monzur Ahmed BSc (Hons), MBChB, MRCP(UK). 
27 Poplar Road, Birmingham, B11 1UH, UK. 
 
email: monz@starlight.demon.co.uk 
       monzur@bigfoot.com 
 
http://www.starlight.demon.co.uk/qibla 
http://www.ummah.org.uk/software/qibla 
 
7th May 1998 
---------------------------------------------------------------------
------- 
 

