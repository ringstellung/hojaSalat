Prayer Time Calculator 
Version 2.9 
 
 
Program and documentation by Dr. Monzur Ahmed 
49 Kempson Avenue, Birmingham, B72 1HE, U.K.

Email:     monzur@bigfoot.com	
           monz@starlight.demon.co.uk
	     
Homepages: http://www.starlight.demon.co.uk/ptc
           http://www.ummah.org.uk/software/ptc

Released 15th July 2001 


----------------------------------------------------------------------------- 
 

    'As to those who hold fast by the Book and establish regular 
 prayer,- never shall We suffer the reward of the righteous to perish.' 
                           (Al-Qur'an 7:17) 

 
----------------------------------------------------------------------------- 
CONTENTS
-----------------------------------------------------------------------------

0. COPYRIGHT

1. INTRODUCTION

2. GETTING STARTED
	2.1  System Requirements
	2.2  Files on Disc
	2.3  Making Backups
	2.4  Running PTC on a floppy drive system
	2.5  Installing and running PTC on a hard drive system
	
3. USING THE COMPUTER PROGRAM

	3.1  OPTION 1: CALCULATE PRAYER TIMES FOR A DAY

	3.2  OPTION 2: CALCULATE PRAYER TIMES FOR A MONTH

	3.3  OPTION 3: DRAW GRAPH OF PRAYER TIMES VERSUS DATE

	3.4  OPTION 4: QIBLA DIRECTION

	3.5  OPTION 5: ADD/DELETE/CHANGE/VIEW ATLAS DATA
		3.5.1  Add data
		3.5.2  Delete data
		3.5.3  Change data
		3.5.4  View data

	3.6  OPTION 6: CHANGE/VIEW DEFAULTS
		3.6.1  Default City
		3.6.2  Default Year
		3.6.3  Which Asr time(s) to be displayed
		3.6.4  Which Fajr and Isha time(s) to be displayed
		3.6.5  Twilight angle
		3.6.6  Start and End of Summer Time/Daylight Saving Time
		3.6.7  Monitor Type
		3.6.8  Custom Line

	3.7  OPTION 7: INFORMATION ON TWILIGHT

4. TECHNICAL INFORMATION

	4.1  Definitions of Prayer Times
	4.2  Persisting Twilight
	4.3  Mathematical Equations for Prayer Times
	4.4  Qibla Direction
	4.5  Shortest Distance to Makkah

5. SHAREWARE/CHARITYWARE

6. FUTURE DEVELOPMENTS

7. CONCLUSION

8. REFERENCES



-----------------------------------------------------------------------------
0. COPYRIGHT
-----------------------------------------------------------------------------

Prayer Times Calculator, associated data files and this document are
copyright (c) by Dr. Monzur Ahmed 1988-2001. All rights reserved.


Prayer Times Calculator may be copied and distributed freely as long as all 
files are copied and no charge is made (other than a nominal charge for media). 
The program must be distributed as its ORIGINAL and UNMODIFIED zip file 
(ptc29.zip). 

No alterations should be made to the program, documentation or data files apart 
from the atlas database, DATA.PTC.

Although Prayer Times Calculator may be distributed freely, it is not 
'Public Domain' nor is it 'Freeware'. All rights remain with the author, 
Dr. Monzur Ahmed.


-----------------------------------------------------------------------------
1. INTRODUCTION
-----------------------------------------------------------------------------

The five Islamic prayers are named Fajr, Zuhr, Asr, Maghrib and Isha. The  
timing of these five prayers varies from place to place and from day to  
day. It is obligatory for Muslims to perform these prayers at the correct  
time. 
 
The prayer times for any given location on earth may be determined  
mathematically if the latitude and longitude of the location are known.  
However, the theoretical determination of prayer times is a complex process  
and would normally be impractical even with the aid of a pocket calculator.  
Much of this tedium may be alleviated by using computers. This computer  
program was developed to allow the non-specialist to calculate prayer times  
accurately for any city in the world.   
 
The program is menu driven and allows the user to simply enter the name of a  
city and the date to obtain the prayer times for that city. Prayer times  
for a single day or for a whole month may be obtained and can be printed  
out or saved to disc for future reference. If your computer supports graphics,
a graph can be obtained showing how the prayer times vary throughout the year
for a given location. British Summer Time and Daylight Saving Time (DST) can 
be automatically compensated for.  
 
In addition to calculating prayer times, the program also calculates the
Qibla direction from any location, the magnetic declination (difference
between magnetic and true north) and the distance of that location from 
Makkah. The program is able to draw world maps (spherical and flat 
projections) showing the position of your location relative to Makkah. 
 
The program has a built in atlas database which can store the longitude and 
latitude data of upto 1000 cities. If a certain city is not already in the 
database, it may be easily added. 
 
 

 
----------------------------------------------------------------------------- 
2. GETTING STARTED 
-----------------------------------------------------------------------------
 
2.1 System Requirements 
======================= 

Prayer Time Calculator (PTC) will work on all PC XT and AT computers and  
compatibles equipped with at least one floppy drive and 512K of memory. 
A hard drive is preferable.  
 
To obtain graphics you will need one of the following graphics adapters:  
CGA, EGA, VGA or Hercules. VGA gives the best results. If you do not
have graphics, then don't worry - you will still be able to obtain displays 
of tables showing prayer times and Qibla direction.  
 
 
 
2.2 Files on Disc 
================= 

The following files should be present on your distribution disc: 
 
	PT29.EXE			The main program 
	DATA.PTC			Contains data for the built in atlas database 
	DEFAULT3.PTC		Contains the initial default settings 
	WORLDMAP.PTC		Contains data to generate map	 
	MAGMODEL.DAT		Data to calculate magnetic declination	
	README.TXT			This file! 
 	WHATSNEW.TXT		Enhancements since last release

Only PT29.EXE is absolutely necessary for the program to function. Even if  
DATA.PTC, DEFAULT3.PTC, MAGMODEL.DAT and WORLDMAP.PTC are missing, the program 
will still run, although sub-optimally. 
	 
	 
 
2.3 Making Backups 
================== 
 
As with all new programs, it is advisable to make backup copies of all the  
files. You should then write protect the original disc and keep it in a  
safe place. Use only the backed up disc. 
 
 
 
2.4 Running PTC on a floppy drive system 
======================================== 
 
Place your disc in, say, drive A. Now make sure you have the A:> prompt  
showing: 
 
A:> 
 
Type PT29 <CR> and the program will commence. 
 
If you wish to save data to the disc ensure that the disc is not write- 
protected. 
 
 
 
 
2.5 Installing and running PTC on a hard drive system 
===================================================== 
 
Let us assume that your hard drive is called drive C. You should initially  
make a directory called e.g. PTIME: 
 
	md c:\ptime   <CR> 
 
Put the floppy disc containing the program into drive A. Copy all the files  
from the floppy disc into the PTIME directory: 
 
	copy a:*.* c:\ptime  <CR> 
 
Ensure that you are logged onto the PTIME directory (IMPORTANT!): 
 
	cd c:\ptime  <CR> 
 
Now type PT29 <CR> and the program will commence. 
 
 
[Technical Note: the program searches the current directory for 
DATA.PTC, DEFAULT3.PTC, MAGMODEL.DAT and WORLDMAP.PTC. It is therefore 
important that you are logged onto the PTIME directory (by typing cd c:\ptime) 
before running the program.] 
 
 

 
----------------------------------------------------------------------------- 
3. USING THE COMPUTER PROGRAM
----------------------------------------------------------------------------- 
 
The program allows the user to chose a city from the built in database or  
a new city may be entered. The prayer time for either a single day or a  
whole month may be tabulated. A graph may be drawn showing how the five prayer
times vary throughout the year for a given city. In addition, the Qibla 
direction and distance to Makkah may be displayed. 
 
When the program is started, you will be presented with a menu:  
 
 
 
                IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII 
                I  Prayer Time Calculator         Version 2.9  I 
                I  By Dr. Monzur Ahmed     (c) Nov 88/July 01  I 
                I                                              I 
                I----------------------------------------------I 
                I               M A I N   M E N U              I 
                I----------------------------------------------I 
                I                                              I 
                I    1. Calculate Prayer Times for one DAY     I 
                I    2. Calculate Prayer Times for one MONTH   I 
                I    3. Graph of Prayer Times vs Date          I 
                I    4. Qibla Direction                        I 
                I    5. Add/ Delete/ Change/ View Atlas Data   I 
                I    6. Change/ View Defaults                  I 
                I    7. Information on Twilight                I 
                I    X. Exit to DOS                            I 
                I                                              I 
                I    Use cursor keys or 1-7 to make choice     I 
                IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII 
 
 
      
You may make a choice from this menu either by using the cursor keys to  
highlight the desired option and pressing enter or by pressing 1,2,3,4,5,6,7 
or X directly. 
 
 
 
3.1  OPTION 1: CALCULATE PRAYER TIMES FOR A DAY 
=============================================== 
 
When this option is chosen (and options 2, 3 and 4), the following screen 
will appear: 
 

IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII       IIIIIIIIIIIIIIIIIIIIIIIIII
ICurrent Place = BIRMINGHAM                   I       I     ABERDEEN           I
IPress ENTER to accept or type in new place   I       I     ACCRA              I
IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII       I     ALGIERS            I
                                                      I     AMSTERDAM          I
NAME OF PLACE ?                                       I     ANKARA             I
                                                      I     ATHENS             I
                                                      I     BAGHDAD            I
                                                      I     BANGKOK            I
                                                      I     BELFAST            I
                                                      I     BERLIN             I
                                                      I     BERNE              I
                                                      I     BIRMINGHAM      << I
                                                      I     BOGOTA             I
                                                      I     BONN               I
                                                      I     BRADFORD           I
                                                      I     BRASILIA           I
                                                      I     BRUSSELS           I
                                                      IIIIIIIIIIIIIIIIIIIIIIIIII
                                                      IIIIIIIIIIIIIIIIIIIIIIIIII
                                                      I  CURSORS & PAGE UP/DN  I
                                                      I     to move pointer    I
                                                      IIIIIIIIIIIIIIIIIIIIIIIIII


 
 
Initially, the location has to be entered. The program comes with a built  
in database of about 100 cities (you can add to or modify this database,  
see section 3.5). The places that are already in the database are listed in 
a scrolling window on the right. You can choose a place from the database  
either by highlighting it with the cursor keys and pressing ENTER or by  
typing the name of the place and pressing ENTER. 
 
If you type in the name of a place which is not in the database, the  
program will ask you to enter the latitude, longitude, reference longitude  
and height above sea level of this place. You will also be asked *if* Summer  
Time operates at this location. (Note that the rules determining *when* Summer 
Time starts and ends can be altered using 'Option 6. Change/View Defaults' 
from the Main Menu; see below). The latitude and longitude should be  
available from a world atlas. The reference longitude is the time zone of  
the place multiplied by 15 (e.g. if the time zone is +3 hours then the  
reference longitude is 15*3= 45E; if the time zone is -7 hours then  
reference longitude= 15*-7=105W; note East is positive, West is negative).  
 
Next, the year, month and date are entered. 
 
The computer then calculates the prayer times. The results may be sent to a 
printer, to the disc (as an ASCII file) or just to the screen, for example: 
 
 
 
=======================================================================
Start of prayer times at BIRMINGHAM on Mon 1 January 2001 :-

   Fajr................... 6:12
   Sunrise................ 8:14
   Zawal..................12:11
   Asr [1]................13:48
   Asr [2]................14:17
   Maghrib/Sunset.........16:08
   Isha...................18:11

=======================================================================
Latitude 52:30N     Longitude 1:55W     Height ASL: 236m
Reference longitude 0:00     Twilight angle am/pm: 18.00/ 18.00 deg
=======================================================================

Press SPACE BAR to return to main menu...

 
************************************************************************** 
** Generally speaking, pressing ESC during the program will either skip **  
** questions (accepting the last set of inputs or defaults) or return   **
** you to the Main Menu.                                                ** 
**************************************************************************
 
 
 
3.2  OPTION 2: CALCULATE PRAYER TIMES FOR A MONTH 
================================================= 
 
Again a city is chosen from the database or entered manually as described  
above. Next the year and month are entered. 
 
A table of prayer times for the month is automatically generated and may be 
sent to a printer, to the disc (as an ASCII file) or just to the screen. If the
table is sent to the disc or printer, the user is allowed to add a custom 
line which will appear at the head of the table. A typical printout is shown 
below: 
 

        In the name of Allah the Beneficent the Merciful
     =======================================================
     BIRMINGHAM  51:30N  1:55W           MARCH 1995

     Reference Longitude 0:00            Time zone: 0.0 hrs
     Twilight angle: 18 degrees          Height ASL: 236m
     Summer Time:   starts  26/3/1995    finishes 22/10/1995

     =======================================================
     Date  Day   Fajr  Sunrise Zawal  Asr[2]  Maghrib   Isha
     =======================================================
      1    Wed   5:04   6:51   12:20   15:53   17:49   19:37
      2    Thu   5:02   6:49   12:20   15:55   17:51   19:39
      3    Fri   4:59   6:47   12:20   15:56   17:53   19:40
      4    Sat   4:57   6:45   12:20   15:58   17:55   19:42
      5    Sun   4:55   6:43   12:19   16:00   17:56   19:44
      6    Mon   4:53   6:40   12:19   16:01   17:58   19:46
      7    Tue   4:50   6:38   12:19   16:03   18:00   19:47
      8    Wed   4:48   6:36   12:19   16:04   18:01   19:49
      9    Thu   4:46   6:34   12:18   16:06   18:03   19:51
     10    Fri   4:43   6:31   12:18   16:07   18:05   19:53
     11    Sat   4:41   6:29   12:18   16:08   18:07   19:55
     12    Sun   4:39   6:27   12:18   16:10   18:08   19:57
     13    Mon   4:36   6:25   12:17   16:11   18:10   19:59
     14    Tue   4:34   6:22   12:17   16:13   18:12   20:00
     15    Wed   4:31   6:20   12:17   16:14   18:14   20:02
     16    Thu   4:29   6:18   12:17   16:16   18:15   20:04
     17    Fri   4:26   6:16   12:16   16:17   18:17   20:06
     18    Sat   4:24   6:13   12:16   16:18   18:19   20:08
     19    Sun   4:21   6:11   12:16   16:20   18:20   20:10
     20    Mon   4:19   6:09   12:15   16:21   18:22   20:12
     21    Tue   4:16   6:07   12:15   16:22   18:24   20:14
     22    Wed   4:14   6:04   12:15   16:24   18:25   20:16
     23    Thu   4:11   6:02   12:15   16:25   18:27   20:18
     24    Fri   4:08   6:00   12:14   16:26   18:29   20:20
     25    Sat   4:06   5:57   12:14   16:28   18:30   20:22
     26*   Sun   5:03   6:55   13:14   17:29   19:32   21:24
     27*   Mon   5:00   6:53   13:13   17:30   19:34   21:26
     28*   Tue   4:58   6:51   13:13   17:32   19:36   21:28
     29*   Wed   4:55   6:48   13:13   17:33   19:37   21:30
     30*   Thu   4:52   6:46   13:12   17:34   19:39   21:33
     31*   Fri   4:50   6:44   13:12   17:35   19:41   21:35
     =======================================================
     NOTES:

     Height ASL: height above sea level in metres
     Reference Longitude: Time Zone x15
     Zawal: Midday - should not pray 5 mins before or after
     Asr[2]: Asr Hanafi (shadow = 2x object)
     * : one hour added for Summer Time

     =======================================================
     Data from  Prayer Time Calculator       Version 2.5
     By Dr. Monzur Ahmed, Birmingham, UK.       Feb 1995
     =======================================================



The number of columns displayed in the table may be altered by the user  
(see section 3.6). Another example of a table displaying all the possible 
columns is shown below: 
 

  
                    You can put a Mosque Name on this line 
==============================================================================
BIRMINGHAM  51:30N  1:55W           MAY 1995

Reference Longitude 0:00            Time zone: 0.0 hrs
Twilight angle: 18 degrees          Height ASL: 236m
Summer Time:   starts  26/3/1995    finishes 22/10/1995

==============================================================================
Date  Day  Fajr/7  Fajr  Sunrise Zawal  Asr[1]  Asr[2]  Maghrib   Isha  Isha/7
==============================================================================
 1*   Mon   4:19   3:13   5:37   13:05   17:07   18:10   20:33   22:57   21:50
 2*   Tue   4:18   3:10   5:35   13:05   17:07   18:11   20:34   23:00   21:51
 3*   Wed   4:17   3:06   5:33   13:05   17:08   18:12   20:36   23:03   21:53
 4*   Thu   4:15   3:02   5:32   13:05   17:09   18:13   20:37   23:07   21:54
 5*   Fri   4:14   2:59   5:30   13:04   17:09   18:14   20:39   23:10   21:55
 6*   Sat   4:13   2:55   5:28   13:04   17:10   18:15   20:41   23:14   21:56
 7*   Sun   4:11   2:51   5:26   13:04   17:11   18:16   20:42   23:17   21:57
 8*   Mon   4:10   2:47   5:24   13:04   17:11   18:17   20:44   23:21   21:58
 9*   Tue   4:09   2:43   5:23   13:04   17:12   18:18   20:46   23:25   21:59
10*   Wed   4:08   2:39   5:21   13:04   17:13   18:19   20:47   23:29   22:01
11*   Thu   4:06   2:35   5:19   13:04   17:13   18:20   20:49   23:33   22:02
12*   Fri   4:05   2:31   5:18   13:04   17:14   18:21   20:50   23:37   22:03
13*   Sat   4:04   2:26   5:16   13:04   17:14   18:22   20:52   23:42   22:04
14*   Sun   4:03   2:22   5:14   13:04   17:15   18:23   20:54   23:46   22:05
15*   Mon   4:02   2:17   5:13   13:04   17:16   18:24   20:55   23:51   22:06
16*   Tue   4:01   2:12   5:11   13:04   17:16   18:25   20:57   23:56   22:07
17*   Wed   4:00   2:07   5:10   13:04   17:17   18:26   20:58    0:01   22:08
18*   Thu   3:59   2:01   5:08   13:04   17:17   18:26   21:00    0:07   22:09
19*   Fri   3:58   1:55   5:07   13:04   17:18   18:27   21:01    0:13   22:11
20*   Sat   3:57   1:49   5:06   13:04   17:18   18:28   21:03    0:20   22:12
21*   Sun   3:56   1:41   5:04   13:04   17:19   18:29   21:04    0:27   22:13
22*   Mon   3:55   1:32   5:03   13:04   17:20   18:30   21:05    0:37   22:14
23*   Tue   3:54   1:17   5:02   13:04   17:20   18:31   21:07    0:51   22:15
24*   Wed   3:53    ??    5:01   13:04   17:21   18:31   21:08     ??    22:16
25*   Thu   3:52    ??    4:59   13:04   17:21   18:32   21:10     ??    22:17
26*   Fri   3:51    ??    4:58   13:05   17:22   18:33   21:11     ??    22:18
27*   Sat   3:51    ??    4:57   13:05   17:22   18:34   21:12     ??    22:19
28*   Sun   3:50    ??    4:56   13:05   17:23   18:35   21:13     ??    22:20
29*   Mon   3:49    ??    4:55   13:05   17:23   18:35   21:15     ??    22:20
30*   Tue   3:49    ??    4:54   13:05   17:24   18:36   21:16     ??    22:21
31*   Wed   3:48    ??    4:53   13:05   17:24   18:37   21:17     ??    22:22
==============================================================================
NOTES:

Height ASL: height above sea level in metres
Reference Longitude: Time Zone x15
Fajr/7: Fajr time using 1/7th night rule
Zawal: Midday - should not pray 5 mins before or after
Asr[1]: Asr Shafi (shadow = 1x object)
Asr[2]: Asr Hanafi (shadow = 2x object)
Isha/7: Isha time using 1/7th night rule
* : one hour added for Summer Time
?? : twilight persists between sunset and sunrise

==============================================================================
Data from  Prayer Time Calculator       Version 2.5
By Dr. Monzur Ahmed, Birmingham, UK.       Feb 1995
==============================================================================


Note how in Birmingham, UK, for the latter half of May the program is unable
to calculate 'normal' Fajr and Isha (indicated by ??) because twilight 
persists between sunset and next sunrise. Under these circumstances the times 
in the Fajr/7 and Isha/7 columns may be used. Fajr/7 and Isha/7 are 
calculated using the 1/7th night rule (see section 4. Technical Notes). In the
above table, both Asr Shafi and Asr Hanafi are displayed. 
 
 
 
 
3.3  OPTION 3: DRAW GRAPH OF PRAYER TIMES VERSUS DATE 
===================================================== 
 
A city is chosen from the list or entered manually. If your computer supports 
graphics, a graph will then be drawn on the screen showing how the prayer 
times vary throughout the year.  
 
The vertical axis represents the time of day (not taking into account  
Summer Time/DST) while the horizontal axis represents the month of the year.  
There will be upto nine curves (depending on the default settings) labelled 
as follows: 
 
 
		F7	=	fajr using 1/7th night rule 
		F	=	fajr (normal) 
		SR	=	sunrise 
		Z	=	zawal 
		A1	=	asr (length of shadow = length of object) 
		A2	=	asr (length of shadow = 2 x length of object) 
		M	=	maghrib/sunset 
		I	= 	isha (normal)
		I7	=	isha using 1/7th night rule 
 
The graph may be printed out on an EPSON compatible dot matrix printer or a
HP Laserjet/Deskjet printer by pressing P and following the prompts.  
(NOTE To abort whilst a graph is being drawn, press ESC). The display may  
be converted to black and white by pressing B. The latter option is useful  
if one wishes to 'grab' the image under Microsoft Windows (by pressing  
Print Screen in enhanced mode) for inclusion in a wordprocessor document. 
 
 
 
 
3.4  OPTION 4: QIBLA DIRECTION 
==============================
 
This option calculates and displays the Qibla direction from a location and 
the shortest distance to Makkah from that location. The location is chosen 
in the usual manner as described above.  

The program gives the option of displaying the result in either TEXT or 
GRAPHICS mode. TEXT mode is recommended for users with slow computers (less 
than a 386 processor). In TEXT mode the result is shown as a simple table:



===============================================================
BIRMINGHAM    52:30N     1:55W       1 January 2001

===============================================================

Qibla Direction (clockwise from TRUE North):  117:57

Magnetic Declination on above date: -3.92 degrees  [ - 3:55 ]
i.e. Magnetic North is 3.92 degrees WEST of True North
Magnetic declination varies with date and location

Distance to Makkah   3076 statute miles (4951 km)
                     2673 nautical miles
===============================================================


In GRAPHICS mode, a world map is drawn showing the position of your location 
relative to Makkah. The default is a spherical projection for the map with 
your location at the centre. The GRAPHICS mode may be slow for users with 
low-powered computers. Several options are available once the map is 
drawn:

   P: printout of map (Epson compatible dot matrix or HP Laserjet/Deskjet)
   S: toggles between a flat and spherical map
   G: toggles between 'glass' and opaque sphere
   Cursors: spin and tilt sphere in 4 directions
   C: puts your location back in the centre
   L: toggles your city and Makkah labels on/off
   N: removes tilt on sphere  

 
Note that the Qibla direction and shortest distance to Makkah are calculated 
using spherical trigonometry. The Qibla direction depends on the 'great circle 
of navigation' which goes through Makkah and your location. The Qibla 
direction is given as the bearing of Makkah from geographic North i.e. degrees 
clockwise from geographic north. The geographic north and magnetic north 
(as determined by a compass) vary depending on location and from year to year. 
The difference between magnetic north and true north is called magnetic 
declination. A positive value for magnetic declination indicates that magnetic 
north is east of true north whilst a negative value indicates that magnetic north 
is west of true north. The geomagnetic field model used in PTC is most accurate 
between 1995 and 2005 although a value will be shown for years in the range 
1990-2010. 
  
When using a magnetic compass to determine qibla direction, one should compensate
for the magnetic declination.

Some of the Qibla angles may seem a little strange. This is because we are 
used to seeing world maps drawn using the Mercator or 'flat' projection 
methods. The Mercator projection was designed for navigation along the so 
called 'Rhumb Line'. Sailing/flying along he Rhumb Line allows the course
to be fixed to one angle for the whole journey. 

The Qibla angle is NOT the direction of a straight line joining your
location to Makkah on a 'flat' map. The earth is spherical and the true
Qibla direction is calculated using spherical trigonometry (see Technical 
Notes). For example, in Alaska the true Qibla direction is North and not 
South-East as a cursory look at a flat map might suggest. If you are still 
confused, examine a globe (and see reference 5 or 6). 
 

 
 
3.5  OPTION 5: ADD/DELETE/CHANGE/VIEW ATLAS DATA 
================================================ 
 
The program has a built in database which can store data for upto 1000  
cities. The program is shipped with about 100 cities already on the  
database. The following pieces of information are stored for each city: 
 
 
	Name of city 
	Country   (optional) 
	Latitude 
	Longitude 
	Reference longitude (15 x Time Band) 
	Whether influenced by Summer Time 
	Height above sea level in metres 
 
Choosing this option allows us to make alterations to the ATLAS DATABASE: 
 
 
 
                IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII 
                I  Prayer Time Calculator         Version 2.9  I 
                I  By Dr. Monzur Ahmed     (c) Nov 88/July 01  I 
                I                                              I 
                I----------------------------------------------I 
                I          A T L A S   D A T A B A S E         I 
                I----------------------------------------------I 
                I                                              I 
                I                                              I 
                I              1. Add data                     I 
                I              2. Delete data                  I 
                I              3. Change data                  I 
                I              4. View data                    I 
                I              X. Exit to Main Menu            I 
                I                                              I 
                I                                              I 
                I                                              I 
                I    Use cursor keys or 1-4 to make choice     I 
                IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII 
 
 
It is best to add a town to the atlas before using it so as to save time 
inputting latitude/longitude data. 
 
 
3.5.1. Add data 
---------------
Follow the prompts and enter the name of the new location, the country  
(optional), the latitude, longitude and reference longitude 
(i.e time zone x 15,  e.g. if the time zone is +3 hours then the reference 
longitude is  15*3= 45E; if the time zone is -7 hours then reference 
longitude= 15*-7=105W). Enter the height of the location above sea level
(zero if you do  not know) and also *whether* summer time (British Summer 
Time/ Daylight Saving Time) should operate. (Note that the rules determining
*when* Summer Time starts and ends can be altered using 'Option 6. Change/View
Defaults' from the Main Menu, see section 3.6.6)
 
Once the location has been entered into the database, it will be saved and  
the name of the location will appear in the scrolling window when option 1,2, 
3 or 4  are chosen from the Main Menu. 
		 
 
3.5.2. Delete data 
------------------
Simply type in the name of a location which exists on the database to  
remove it from the database. Make sure that the spelling is correct (although
the case does not matter). 
 
 
3.5.3. Change data 
------------------
Type in the name of a location which already exists on the database and  
follow the prompts to alter its properties. 
 
 
3.5.4. View data 
----------------
This generates a table showing all the locations stored in the database in  
alphabetical order. Use Page Up/Down to browse.  
 
 
 
 
3.6  OPTION 6: CHANGE/VIEW DEFAULTS 
=================================== 
 
The following screen is displayed: 
 

 
  ___________________________________________________________________________
  _                         CURRENT DEFAULT SETTINGS                        _
  _                                                                         _
  _ Default City: BIRMINGHAM                                                _
  _ Default Year: 2001                                                      _
  _ Asr time to be displayed: 3                                             _
  _   where [1]:  shadow = length of object                                 _
  _         [2]:  shadow = 2 x length of object                             _
  _         [3]:  both                                                      _
  _ Fajr and Isha times to be displayed: 1                                  _
  _   where [1]:  normal                                                    _
  _         [2]:  1/7th night rule (Sube Al-Lail)                           _
  _         [3]:  both                                                      _
  _ Twilight angle for Fajr: 18.00 degrees                                  _
  _ Twilight angle for Isha: 18.00 degrees                                  _
  _ Summer Time, if present, begins on last Sunday of month 3               _
  _                          ends on last Sunday of month 10                _
  _ Monitor Type: Colour                                                    _
  _ Custom Line:In the name of Allah the Beneficent the Merciful            _
  _                                                                         _
  _                    Press SPACE BAR to make changes...                   _
  ___________________________________________________________________________




 
Pressing the Space Bar allows the user to change the following values which  
are stored as defaults and remembered when the program is next run: 
 
3.6.1  Default City - usually set to the users home town. 
-------------------

 
3.6.2  Default Year - usually set to the current year.
-------------------

 
3.6.3  Which Asr time(s) to be displayed 
----------------------------------------	
	Asr1 (length of shadow = length of object),  
	Asr2 (length of shadow = 2x length of object)  
	or both. 

 
3.6.4  Which Fajr and Isha time(s) to be displayed 
--------------------------------------------------
	Normal  
	Fajr and Isha using 1/7 night rule (Sube Al-Lail)  
	or both. 

 
3.6.5  Twilight angle 
---------------------
You can choose twilight angles for fajr and isha.
Generally the twilight angles should be 18 degrees for both fajr and isha
although the program will different values for fajr and isha in the range:
10 to 20 degrees. 

   
3.6.6  Start and End of Summer Time/Daylight Saving Time
--------------------------------------------------------
The rules for the start and finish of Summer Time or Daylight Saving Time 
(DST) vary from country to country. For example, in 1986 the effective 
periods for DST for various countries were as follows (data from reference 8):

===========================================================  
COUNTRY              Effective DST period (dates inclusive)
===========================================================
AUSTRALIA		26 OCT 86	-	28 FEB 86
CANADA		27 APR 86	-	25 OCT 86
FRANCE		30 MAR 86	-	27 SEP 86
IRAQ			01 APR 86	-	30 SEP 86
ITALY			30 MAR 86	-	27 SEP 86
JORDAN		04 APR 86	-	02 OCT 86
SPAIN			30 MAR 86	-	27 SEP 86
SYRIA			16 FEB 86	-	18 OCT 86
TURKEY		30 MAR 86	-	27 SEP 86
USA			27 APR 86	-	25 OCT 86
UK			30 MAR 86	-	25 OCT 86
===========================================================

During DST, one hour (in most countries) is added to the standard time.
In many countries there are general rules for the start and end of DST. For
example, in the UK,  DST (British Summer Time) usually starts on the 
fourth Sunday of March and ends on the fourth Sunday of October. Similarly,
in most areas of the USA, DST starts on the last Sunday of April and ends 
on the last Sunday of October.

The DST handling of the program has been designed to be flexible enough to 
cater for most countries of the world. The start/end of DST can be set either 
as an *absolute* date e.g. 1st May or in a *relative* way e.g. fourth Sunday
of March.

Essentially you have to answer 3 questions (following the prompts) to set
the start or end of DST:

Q1. The month when DST starts or ends.

Q2. The day on which DST starts or ends.
	- for absolute date, choose 'Specific date' for this question.
	- for relative date, choose a day name e.g. 'Sunday'

Q3. The position of the day in the month.
	- for absolute date, enter the date when you want DST to start/end.  
      	- for relative date, enter the position of the day in the month 
	  i.e. first, second, third, fourth or last. For example if you want 
	  DST to start on the last Sunday of the chosen month, enter 'last' 
	  or if you want DST to start on the fourth Sunday, enter 'fourth'.

Example 1. If you want DST to start on 1st April, the three questions
should be answered as follows:
	Q1. 4
	Q2. Specific date
	Q3. 1

Example 2. If you want DST to start on the last Sunday of April, the three
questions should be answered as follows:
	Q1. 4
	Q2. Sunday
	Q3. last

The program ships with default start/end of DST valid for the UK i.e. DST 
starts on the fourth Sunday of March and ends on fourth Sunday of October. 
If the Summer Time/DST rules are different for your location then you must 
alter the rules using this option. If you specify that Summer Time/DST 
does not apply for your location then these rules will be ignored. 

   
3.6.7  Monitor Type: Colour or Black & White 
------------------- 


3.6.8  Custom Line 
------------------
This is a line of text, maximum 60 characters in length, which can appear at 
the top of a table printed out or saved to disc. This feature can be used to 
customise a printed prayer time table. 
	 


3.7  OPTION 7: INFORMATION ON TWILIGHT 
====================================== 

This option produces a screen which provides information on the persistence  
of twilight at extreme latitudes. A brief summary of the four methods of  
calculating alternative fajr/isha times is displayed. 
 

 
 
-----------------------------------------------------------------------------
4. TECHNICAL INFORMATION 
----------------------------------------------------------------------------- 
 
4.1 Definitions of Prayer Times 
=============================== 
 
The five Islamic prayers are termed Fajr, Zuhr, Asr, Maghrib and Isha.  
Twilight is the period before sunrise and after sunset when the sky is  
partially illuminated by scattered sunlight. The start of fajr and isha  
depend on twilight. In astronomy, the twilight period is divided into civil,
nautical and astronomical twilight which come to an end when the solar 
depression  is 6, 12, and 18 degrees respectively.  
 
For the purpose of calculating fajr and isha times a solar depression of  
18 degrees is generally used i.e. astronomical twilight. 
 
At extreme latitudes solar depression may not exceed 18 degrees for certain 
months of the year and hence twilight persists between sunset and next sunrise  
(see below). 
 
 
* FAJR starts with the dawn or morning twilight. Fajr ends just before  
sunrise. 
 
* ZUHR begins after mid-day when the sun has passed the meridian (i.e. after  
zawal). For convenience, many published prayer timetables add five  
minutes to zawal to obtain the start of Zuhr. Zuhr ends at the start of  
Asr time. 
 
* The timing of ASR depends on the length of the shadow cast by an object.  
According to the Shafi school of jurisprudence, Asr begins when the  
length of the shadow of an object exceeds the length of the object. According  
to the Hanafi school of jurisprudence, Asr begins when the length of the  
shadow exceeds TWICE the length of the object. In both cases, the minimum  
length of shadow (which occurs when the sun passes the meridian) is  
subtracted from the length of the shadow before comparing it with the  
length of the object. 
 
* MAGHRIB begins at sunset and ends at the start of isha.  
  
* ISHA starts after dusk when the evening twilight disappears. 
 
 
 
4.2 Persisting Twilight 
======================= 
 
At extreme latitudes the twilight may persist between sunset and the next  
sunrise. Hence there is no true night. Under these circumstances, Fajr and  
Isha times may be calculated using one of four agreed principles: 
 
 
1.  Nearest latitude (Aqrab Al-Balad) - add the interval between sunset and  
isha for a location on latitude 48 degrees to the local sunset time to  
obtain time for local isha. Similarly the interval between fajr and sunrise 
for a location on latitude 48 degrees is subtracted from local sunrise to 
obtain local fajr time.  
 
2.  Nearest day (Aqrab Al-Ayyam) - use fajr and isha times from the last  
day when it was possible to calculate these times in the normal way for 
that location. 
 
3.  Middle of night (Nisf Al-Lail) - split interval between sunrise and  
sunset into two halves. Isha is offered before the midpoint (e.g. 15 minutes  
before) and fajr is offered after the midpoint. 
 
4. One seventh of night (Sube Al-Lail) - split interval between sunset and  
sunrise into seven segments. Isha is offered after the first segment and   
fajr is offered after the sixth segment. 
 
 
The program uses the fourth method (1/7th night rule) to give alternative 
fajr and isha times for use when the normal times are undefined. These 
alternative fajr and isha times are provided as a guide only. They should 
not be regarded as absolute standards. Some users may find  that one of 
the other three alternatives is more suitable for their location. Whichever 
method is used to calculate alternative Fajr/ Isha times, it is important 
that the same method is used for both fasting and prayer! The phenomenon 
of persisting twilight does not occur for locations within the latitude 
range 48S to 48N (approximately) when a twilight angle of 18 degrees is used. 
 
 
 
4.3 Mathematical Equations for Prayer Times 
=========================================== 
 
To calculate the prayer times for a certain place we need to know the  
latitude (B) and longitude  (L) of the location and its reference 
longitude (R). B and L may be obtained from an atlas and R may be calculated 
by multiplying 15 by the difference between local time and GMT 
(i.e. 15 x Time Band). 
 
We also need to know two astronomical measures called the declination angle 
of the sun (D) and the real time-mean time difference, also known as the 
equation of time (T).  
 
Declination is the angular distance between a celestial object and the  
celestial equator. The Declination and the Right Ascension are used  
together to give the position of a star with reference to the celestial  
equator and the vernal equinox respectively. 
 
The equation of time is a correction to be added to apparent solar time, 
as read on a sundial, to obtain mean solar time, as commonly used. This  
difference is a consequence of the ellipticity and tilt of the Earth's  
orbit, causing the irregular apparent movement of the Sun across the sky. 
 
D and T vary according to the time of year and can be obtained accurately  
from The Star Almanac or calculated approximately as in this program. 
  
The following equations may be used to calculate the prayer times: 
 
 
 
	(R-L)    T 
Z = 12+ ----- + ---							........1 
	 15      60			 
  	               			  
 
 
 
    1        {sin(-0.8333-0.0347(H)^0.5)}-sinD.sinB 
U= -- arccos --------------------------------------  		........2
   15                   cosD.cosB          
			                  
 
 
 
    1        -sinG-sinD.sinB 
V= -- arccos --------------- 			   			........3
   15          cosD.cosB 
                                        
 
 
 
    1        sin{arccot(1+tan ABS(B-D))}-sinD.sinB 
W= -- arccos ------------------------------------- 		........4
   15                 cosD.cosB 
                                  
 
 
 
    1        sin{arccot((2+tan ABS(B-D)}-sinD.sinB 
X= -- arccos ------------------------------------- 		........5
   15                 cosD.cosB 
 			 
				 
 
 
where  
 
B= latitude of place 
L= longitude of place 
R= reference longitude (i.e. TIME BAND x 15) 
H= height above sea level in metres 
D= declination angle of sun from celestial equator (-ve in southern hemisphere)
T= mean time - real time difference, i.e. equation of time 
G= twilight angle 
ABS = absolute value of 

Fajr = Z-V 
Sunrise = Z-U  
Zuhr  = Z 
Asr1 (Shafi) = Z+W 
Asr2 (Hanafi) = Z+X 
Maghrib/Sunset = Z+U 
Isha = Z+V 
 
 
The program automatically calculates approximate values for T and D from  
the date (algorithms not shown here). Zuhr time is calculated using equation 1.
The time for sunrise and sunset/ maghrib may be calculated by subtracting or
adding 'U'(obtained from equation 2) to the Zuhr time respectively. In 
calculating sunrise and sunset, the program takes into account the height of
the location above sea level (if it has been entered into the database). 
 
Fajr and Isha times may be calculated by subtracting or adding 'V'  
(obtained from equation 3) to the Zuhr time respectively. The term G  
(twilight angle) in equation 3 is usually set to 18 degrees.  
For a location with an extreme latitude, days in summer may be so long that 
twilight persists between sunset and the next sunrise. Under these  
circumstances, 'V' is undefined and Fajr and Isha have to be determined  
using agreed principles of fiqh. Version 2.x  of the program is able to  
display 'fajr/7' and 'isha/7'  i.e. when there is no 'true night' (twilight  
persists between sunset and next sunrise) the period between sunset and  
next sunrise is divided into seven segments.  Isha is performed after the 
first segment and fajr after six segments as described above. 
 
The start of Asr time (Shafi) may be obtained by adding 'W' (obtained from  
equation 4) to Zuhr; Asr time (Hanafi) is calculated by adding 'X' obtained
from equation 5) to Zuhr. 

 
 
 
4.4 Qibla Direction 
=================== 
 
The Qibla direction may be calculated by using spherical trigonometry. 
 
 
 
		 	sin(Lm-L) 
Q = arctan	------------------------------- 
        	cos(B).tan Bm - sin B.cos(Lm-L) 
 
 
 
where 

Q= Qibla bearing from geographic North 
Lm= longitude of Makkah 
L= longitude of place 
Bm= latitude of Makkah 
B= latitude of place 
 
Although the program allows the latitude and longitude of a location to be 
entered to the nearest minute, for the purposes of calculating Qibla direction,
the reference co-ordinates of Makkah (Kaaba) are stored internally  with 
greater accuracy i.e. 21:25:16 N and 39:49:29.1 E. 

Note that the Qibla direction is relative to geographic north and not 
magnetic north (as determined by a compass). Geographic and magnetic norths 
will vary depending on location. This difference is known as magnetic 
declination and also varies with time. Information on magnetic 
declinations for a particular location may be obtained from magnetic atlases 
(e.g. reference 9). PTC calculates magnetic declination using a computer model
based on reference data collected from various magnetic stations throughout 
the world. This model is most accurate between 1995 and 2005. After 2005, the
magmodel.dat should be replaced with a more up to date file.

From a practical point of view, geographic north-south may be determined
using the time of local solar meridian crossing (zawal). The program 
automatically calculates and displays zawal. At this time, a vertical rod 
placed on the ground will cast a shadow along the geographic north-south 
axis.



4.5 Shortest Distance to Makkah
=============================== 

The shortest distance of a place from Makkah in nautical miles is: 
 
	Distance = 60*arcos {sin B.sin(Bm) + cos B.cos Bm.cos(Lm-L)} 
 
Note:  
	1 International Nautical Mile	= 1.150779 statute miles  
					= 1.852km exactly 
					= 2025 yards approximately 

	1 Statute Mile = 1760 yards = 1.609km 
 
 


 
----------------------------------------------------------------------------- 
5. SHAREWARE/CHARITYWARE 
----------------------------------------------------------------------------- 
 
This program was developed over a period of more than 12 years. You may copy 
and distribute the program FREELY as long as no alterations are made to the 
program or documentation and no charge is made (other than a reasonable charge 
for the media and copying). Please ensure that ALL the files, including 
documentation, are copied. 

The copyright for the program and documentation remains with the author.
 
If you find the program useful, then you are requested to make a donation 
to an Islamic charity. 
  
 
-----------------------------------------------------------------------------
6. FUTURE DEVELOPMENTS
-----------------------------------------------------------------------------

Prayer Times Calculator is under constant development. Some possible
enhancements for future releases include:

*Improved Summer Time/ Daylight Saving Time routines. If the present DST 
options are not suitable for your location then switch this feature off and 
manually adjust the times.

*Mouse support and perhaps a WIMP environment.

*If there is sufficient demand, I may produce a Windows version.

*I am also developed several other programs:

MoonCalc for DOS
http://www.ummah.net/ildl/mooncalc.html
http://www.starlight.demon.co.uk/mooncalc
Provides vast amount of data about the moon, its visibility and the Islamic
calendar.

QiblaCalc for Windows
http://www.ummah.net/software/qibla
http://www.starlight.demon.co.uk/qibla
Graphically shows the Qibla as user passes mouse cursor over a world map; 
very user-friendly interface.

CyberSalat for Windows
http://www.ummah.net/software/cyber
Interactive multimedia salat tutor.



----------------------------------------------------------------------------- 
7. CONCLUSION 
-----------------------------------------------------------------------------
 
For further information or if you have any suggestions to improve the  
program, please contact me at the address below. 
 
I am grateful to the many people who helped in the development of this  
program. In particular I should like to thank Shakoor Chugthai for his 
helpful suggestions and extensive error testing. Any errors or omissions 
that remain are entirely my own. May Allah forgive us all. 
 
Wasalaam. 
 
=============================================================================
Dr. Monzur Ahmed  BSc(Hons), MBChB, MRCP, MD.                           
49 Kempson Avenue, Sutton Coldfield, B72 1HE, UK.                                
               
email: 	monzur@bigfoot.com
		monz@starlight.demon.co.uk
                                                          
15th July 2001                                                      
============================================================================= 

 
-----------------------------------------------------------------------------
8. REFERENCES 
-----------------------------------------------------------------------------
 
1. Dr Husein Kamaluddin [in Arabic] in The Islamic Researches Magazine,  
1397AH, vol 1, No 3, Pub: Presidency of Scientific Researches, Ifta, Call  
and Guidance (Saudi Arabia). 
 
2. Dr Muhmoud N. Nahas; Determination of Prayer Times, The Muslim, December  
1985: 12-14. 
 
3. The Star Almanac for Land Surveyors, London, HMSO. 
 
4. Mufti Rasheed Ahmed Ludhyanvi; Ahsunul Fatawa, 1405 AH, HM Saeed Company 
Publishers, Pakistan. 
 
5. Dr. Mohammad Ilyas; Astronomy of Islamic Times for the Twenty-first Century,
1989; Mansell, London. 
 
6. Dr. Mohammad Ilyas; A Modern Guide to Astronomical Calculations of Islamic
Calendar, Times & Qibla;1984,Berita Publishing Sdn Bhd., Kuala Lumpur, 
Malaysia

7. Moulana Yakub Qasmi and Tariq Muneer, Prayer Times for United Kingdom &  
Ireland; 1989, Islamic Research Institute of Britain, Dewsbury, UK. 

8. Abdul Lateef Bin Abdul Aziz, Perpetual Prayer Time Table for the Whole
World; 1986, Published by Abdul Majeed Qureshi, Karachi, Pakistan.

9. Magnetic Variation (Declination) (Epoch 1990); Map No.42 10th Ed; 1992, 
World Map, USA Defence Mapping Agency
